// 0x0E0005B0
const GeoLayout geo_bbh_0005B0[] = {
   GEO_CULLING_RADIUS(700),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bbh_seg7_dl_0701F2E8),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
