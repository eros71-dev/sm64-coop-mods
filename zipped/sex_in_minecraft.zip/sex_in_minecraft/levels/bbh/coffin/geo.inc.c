// 0x0E000658
const GeoLayout geo_bbh_000658[] = {
   GEO_CULLING_RADIUS(800),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bbh_seg7_dl_070206F0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
