// 0x0E0005E0
const GeoLayout geo_bbh_0005E0[] = {
   GEO_CULLING_RADIUS(650),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bbh_seg7_dl_0701F7E8),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
