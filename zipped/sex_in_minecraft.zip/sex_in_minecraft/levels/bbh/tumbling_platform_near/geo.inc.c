// 0x0E0005F8
const GeoLayout geo_bbh_0005F8[] = {
   GEO_CULLING_RADIUS(300),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bbh_seg7_dl_0701FAB0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
