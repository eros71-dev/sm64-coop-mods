// 0x0E0005C8
const GeoLayout geo_bbh_0005C8[] = {
   GEO_CULLING_RADIUS(600),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bbh_seg7_dl_0701F5F8),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
