// 0x0E000640
const GeoLayout geo_bbh_000640[] = {
   GEO_CULLING_RADIUS(2300),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, bbh_seg7_dl_070202F0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
