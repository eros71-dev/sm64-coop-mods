-- name: Throwback Galaxy Remix
-- description: Makes Bob-omb Battlefield's music\nsound smilar to Throwback Galaxy\nfrom Super Mario Galaxy 2.\n\nBy \\#d6c899\\eros\\#6fb900\\71\\#ffffff\\.

smlua_audio_utils_replace_sequence(SEQ_LEVEL_GRASS, 34, 127, "bob")