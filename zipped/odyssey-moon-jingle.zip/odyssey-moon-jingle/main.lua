-- name: Odyssey Star Fanfare Mod
-- description: Replaces the SM64 Star Get Fanfare with the Super Mario Odyssey one, but in the SM64 style.\nRecommended to be used along with Isaac's OMM mod!

smlua_audio_utils_replace_sequence(SEQ_EVENT_CUTSCENE_COLLECT_STAR, 34, 100, "star")