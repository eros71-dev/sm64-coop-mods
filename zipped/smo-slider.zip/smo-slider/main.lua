-- name: Odyssey Race/Slider Remix
-- description: Replaces the race music with\the one from Super Mario Odyssey\while keeping the SM64 slider style.\n\nBy \\#d6c899\\eros\\#6fb900\\71\\#ffffff\\.

smlua_audio_utils_replace_sequence(SEQ_LEVEL_SLIDE, 13, 127, "slider")